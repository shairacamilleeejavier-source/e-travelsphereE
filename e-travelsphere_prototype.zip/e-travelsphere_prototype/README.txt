
e-TravelSphere Prototype (HTML)
Files included:
- index.html : single-page interactive prototype you can open in a browser.
How to use:
1. Download the zip and extract.
2. Open index.html in your browser (Chrome/Edge/Firefox).
3. Click map pins, 'Start Quest', or 'View' on posts to see modal interactions.
